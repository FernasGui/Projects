package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.isInteractive;
import pt.iscte.poo.utils.Point2D;

public class Teleporte extends GameElement implements isInteractive {
    private Point2D destino; //destino do teleporte

    // Este é o construtor que já existia
    public Teleporte(Point2D position, String imageName) {
        super(position, imageName, 1);
    }
    
    // Novo construtor 
    public Teleporte(Point2D position, String imageName, Point2D destino) {
        super(position, imageName, 1);
        this.destino = destino;
    }

	@Override
	public boolean eTransponivel() {
		return true;
	}

	@Override
	public boolean canBePickedUp() {
		return false;
	}

	// Obtém o destino do teleporte
	public Point2D getDestino() {
		return destino;
	}

	@Override
	public void onInteraction(GameElement element) {
		// A lógica de interação será tratada no GameEngine
	}
}
