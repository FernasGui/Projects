package pt.iscte.poo.sokobanstarter.Elements;

import java.util.List;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.utils.Point2D;

public class Buraco extends GameElement {

	private boolean coberto;

	public Buraco(Point2D Point2D, String imageName) {
		super(Point2D, "Buraco", 1);
		this.coberto = false;
	}

	public void setCoberto(boolean coberto) {
		this.coberto = coberto;
	}

	@Override
	public boolean eTransponivel() {
		return true;
	}

	public boolean isCoberto() {
        List<GameElement> elementosNaPosicao = GameEngine.getInstance().getElementInPosition(this.getPosition());
        for (GameElement elemento : elementosNaPosicao) {
            if (elemento instanceof Palete ) {
                return true;
            }
        }
        return false;
    }
}