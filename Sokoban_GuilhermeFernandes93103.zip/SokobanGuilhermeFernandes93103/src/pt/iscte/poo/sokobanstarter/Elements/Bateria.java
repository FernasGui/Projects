package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.sokobanstarter.isInteractive;
import pt.iscte.poo.utils.Point2D;

public class Bateria extends GameElement implements isInteractive {

	private int ENERGIA_ADICIONADA = 50;

	public Bateria(Point2D Point2D, String imageName) {
		super(Point2D, "Bateria", 1);
	}

	@Override
	public boolean eTransponivel() {
		return true;
	}

	@Override
	// Método que verifica se o objeto pode ser apanhado ou interagido
	public boolean canBePickedUp() {
		return true;
	}

	@Override
	public void onInteraction(GameElement element) {
		if (element instanceof Empilhadora) {
			// Cast do element para Empilhadora
			Empilhadora empilhadora = (Empilhadora) element;

			// Adiciona energia à empilhadora
			empilhadora.adicionarEnergia(ENERGIA_ADICIONADA); // ENERGIA_ADICIONADA é um valor constante 50 deste caso 

			// Remove a bateria do jogo
			GameEngine.getInstance().removeFromGame(this);
		}
	}
}
