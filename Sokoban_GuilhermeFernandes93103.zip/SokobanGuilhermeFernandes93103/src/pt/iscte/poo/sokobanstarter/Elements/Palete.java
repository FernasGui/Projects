package pt.iscte.poo.sokobanstarter.Elements;

import java.util.List;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.sokobanstarter.Moveable;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Palete extends Moveable {
	private boolean cobrindoBuraco;
	private boolean fixadaNoBuraco;

	public Palete(Point2D Point2D, String imageName) {
		super(Point2D, "Palete", 2);
		this.cobrindoBuraco = false;
		this.fixadaNoBuraco = false;
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}

	public void setCobrindoBuraco(boolean estado) {
		cobrindoBuraco = estado;
	}

	public void fixarNoBuraco() {
		this.fixadaNoBuraco = true;
	}

	@Override
	public void move(Direction d) {
		if (!fixadaNoBuraco) {
			super.move(d);
			verificarEfixarNoBuraco();
		}
	}

	public void verificarEfixarNoBuraco() {
		List<GameElement> elementsAtPosition = GameEngine.getInstance().getElementInPosition(getPosition());
		for (GameElement element : elementsAtPosition) {
			if (element instanceof Buraco) {
				fixarNoBuraco();
				break;
			}
		}
	}
}