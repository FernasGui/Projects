package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Chao extends GameElement implements ImageTile {

	public Chao(Point2D Point2D, String imageName) {
		super(Point2D, "Chao", 0);
	}

	@Override
	public boolean eTransponivel() {
		return true;
	}

}
