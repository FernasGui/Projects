package pt.iscte.poo.sokobanstarter.Elements;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.sokobanstarter.Moveable;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Empilhadora extends Moveable {

	private static final int MAX_BATERIA = 100;
	private int nivelBateria;
	private boolean temMartelo = false;

	public Empilhadora(Point2D position, String imageName) {
		super(position, imageName, 2);
		this.nivelBateria = 100; // Inicializa com o nível de bateria cheio
	}

	// metodo para mudar a imagem da acordo com direçao
	public void setImage(Direction d) {
		switch (d) {
		case UP:
			setImage("Empilhadora_U");
			break;
		case DOWN:
			setImage("Empilhadora_D");
			break;
		case LEFT:
			setImage("Empilhadora_L");
			break;
		case RIGHT:
			setImage("Empilhadora_R");
			break;
		}
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}

	@Override
	public void move(Direction d) {
	    Point2D newPosition = getPosition().plus(d.asVector());

	    // Processar interações com outros elementos
	    processInteractions(newPosition, d);

	    // Se a nova posição tem um buraco coberto por uma palete
	    if (isPaleteOnBuraco(newPosition)) {
	        // Remover palete e buraco se ambos estiverem na mesma posição
	        removerPaleteEBuraco(newPosition);
	    }

	    // Verifica se a empilhadora pode se mover para a nova posição
	    if (canMove(d)) {
	        setPosition(newPosition);
	        setImage(d);
	        GameEngine.getInstance().updateElementPosition(this, newPosition);
	    }
	}

	private void processInteractions(Point2D newPosition, Direction d) {
		// Obtém a lista de elementos na nova posição
		List<GameElement> elementsInNewPosition = GameEngine.getInstance().getElementInPosition(newPosition);

	    for (GameElement element : elementsInNewPosition) {
	        if (element instanceof Moveable) {
	            Moveable moveableElement = (Moveable) element;
	            verificarETeletransportar(d);
	            moveableElement.move(d);
	            
	        } else if (element instanceof ParedeRachada && temMartelo()) {
	            interagirComParedeRachada(d, element);
	            break;// Interrompe a movimentação se uma parede rachada for quebrada
	            
	        } else if (element instanceof Teleporte) {
	        	interagirComTeleporte(element);
	            newPosition = getPosition();	            
	        }
	    }
	}


	// BURACO E PALETE
	
	private void removerPaleteEBuraco(Point2D position) {
	    //obtem todos os elementos que estão na posição atual da empilhadora
		List<GameElement> elementosNaPosicao = GameEngine.getInstance().getElementInPosition(position);
	    Palete paleteRemovida = null;
	    Buraco buracoRemovido = null;
	   // percorre esses elementos e, se encontrar uma palete e um buraco, remove ambos do jogo.
	    for (GameElement elemento : elementosNaPosicao) {
	        if (elemento instanceof Palete) {
	            paleteRemovida = (Palete) elemento;
	            GameEngine.getInstance().removeElement(elemento);
	        } else if (elemento instanceof Buraco) {
	            buracoRemovido = (Buraco) elemento;
	            GameEngine.getInstance().removeElement(elemento);
	        }
	    }

	    if (paleteRemovida != null && buracoRemovido != null) {
	    }
	}

	private boolean isPaleteOnBuraco(Point2D position) {
		//obtem todos os elementos que estão na posição atual da empilhadora
		List<GameElement> elementsAtPosition = GameEngine.getInstance().getElementInPosition(position);
		boolean paleteEncontrada = false;
		boolean buracoEncontrado = false;
		// percorre esses elementos
		for (GameElement elemento : elementsAtPosition) {
			if (elemento instanceof Palete) {
				paleteEncontrada = true;
			} else if (elemento instanceof Buraco) {
				buracoEncontrado = true;
			}

			// Se ambos, palete e buraco, forem encontrados, retorna verdadeiro
			if (paleteEncontrada && buracoEncontrado) {		
				return true;
			}
		}

		// Retorna falso se não encontrar ambos na mesma posição
		return false;
	}
	


	// MARTELO E PAREDE RACHADA
	private void interagirComParedeRachada(Direction d, GameElement element) {
		ParedeRachada parede = (ParedeRachada) element;
		parede.quebrar(); // Quebra a parede rachada
	}

	public void pegarMartelo() {
		temMartelo = true;
	}

	public boolean temMartelo() {
		return temMartelo;
	}

	public void usarMartelo(ParedeRachada parede) {
		if (temMartelo) {
			parede.quebrar(); // Método na classe ParedeRachada para quebrar a parede
		}
	}

	// TELEPORTE
	// Este metodo verifica a intereçao com o teleporte
	private void interagirComTeleporte(GameElement element) {
		Teleporte teleporte = (Teleporte) element;
		Point2D destino = teleporte.getDestino();
		if (destino != null) {
			setPosition(destino); // Move para o destino do teleporte
		}
	}

	// Verifica se pode teleportar- se e para onde se teleporta
	public void verificarETeletransportar(Direction d) {
		Point2D nextPosition = getPosition().plus(d.asVector());
		List<GameElement> nextElements = GameEngine.getInstance().getElementInPosition(nextPosition);

		for (GameElement nextElement : nextElements) {
			if (nextElement instanceof Teleporte) {
				Teleporte teleporte = (Teleporte) nextElement;
				Point2D destino = teleporte.getDestino();
				if (destino != null) {
					setPosition(destino);
					GameEngine.getInstance().updateElementPosition(this, destino);
					break;
				}
			}
		}
	}

	// BATERIA
	// Este método é chamado quando a empilhadora se move
	public void diminuirEnergia() {
		// Decrementa a energia a cada movimento
		nivelBateria--;
	}

	// Este método adiciona energia à empilhadora
	public void adicionarEnergia(int energia) {
		this.nivelBateria += energia;
		// Verifica que o nível de bateria não ultrapasse o máximo permitido
		if (nivelBateria > MAX_BATERIA) {
			nivelBateria = MAX_BATERIA;
		}
	}

	// Este método devolve o nivel de bateria
	public int getNivelBateria() {
		return this.nivelBateria;
	}
}
