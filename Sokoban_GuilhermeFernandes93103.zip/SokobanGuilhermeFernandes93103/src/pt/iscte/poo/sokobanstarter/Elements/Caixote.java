package pt.iscte.poo.sokobanstarter.Elements;

import java.util.List;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.sokobanstarter.Moveable;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Caixote extends Moveable {
	public Caixote(Point2D Point2D, String imageName) {
		super(Point2D, "Caixote", 2);
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}
	@Override
    public void move(Direction d) {
        Point2D newPosition = getPosition().plus(d.asVector());
        if (canMove(d)) {
            if (verificarETeletransportar(newPosition)) {
                return; // Se teletransportado, não precisa mover mais
            }
            setPosition(newPosition);
            GameEngine.getInstance().updateElementPosition(this, newPosition);
        }
    }

    private boolean verificarETeletransportar(Point2D newPosition) {
        List<GameElement> elementsAtNewPosition = GameEngine.getInstance().getElementInPosition(newPosition);
        for (GameElement element : elementsAtNewPosition) {
            if (element instanceof Teleporte) {
                Teleporte teleporte = (Teleporte) element;
                Point2D destino = teleporte.getDestino();
                if (destino != null) {
                    setPosition(destino);
                    GameEngine.getInstance().updateElementPosition(this, destino);
                    return true; // Indica que ocorreu um teletransporte
                }
            }
        }
        return false; // Não ocorreu teletransporte
    }
}