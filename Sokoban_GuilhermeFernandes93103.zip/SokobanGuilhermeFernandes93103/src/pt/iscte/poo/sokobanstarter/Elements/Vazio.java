package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Vazio extends GameElement {
	public Vazio(Point2D Point2D, String imageName) {
		super(Point2D, "Vazio", 0);
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}
}