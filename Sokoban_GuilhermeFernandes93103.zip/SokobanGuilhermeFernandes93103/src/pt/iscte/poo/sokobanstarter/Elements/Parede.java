package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Parede extends GameElement {
	public Parede(Point2D Point2D, String imageName) {
		super(Point2D, "Parede", 1);
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}
}
