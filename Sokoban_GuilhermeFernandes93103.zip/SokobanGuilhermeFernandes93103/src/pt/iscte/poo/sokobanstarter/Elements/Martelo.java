package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.sokobanstarter.isInteractive;
import pt.iscte.poo.utils.Point2D;

public class Martelo extends GameElement implements isInteractive{
	public Martelo(Point2D Point2D, String imageName) {
		super(Point2D, "Martelo", 1);
	}

	@Override
	public boolean eTransponivel() {
		return true;
	}
	@Override
	// Método que verifica se o objeto pode ser apanhado ou interagido
	public boolean canBePickedUp() {
		return true;
	}

	// Método que define a ação ao interagir com o objeto
	  @Override
	    public void onInteraction(GameElement element) {
	        if (element instanceof Empilhadora) {
	            Empilhadora empilhadora = (Empilhadora) element;
	            empilhadora.pegarMartelo();
	            GameEngine.getInstance().removeFromGame(this);
	        }
	    }
}
