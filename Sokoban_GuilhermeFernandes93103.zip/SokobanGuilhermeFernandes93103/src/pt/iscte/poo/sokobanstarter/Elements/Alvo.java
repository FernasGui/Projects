package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Alvo extends GameElement {
	public Alvo(Point2D Point2D, String imageName) {
		super(Point2D, "Alvo", 1);
	}

	@Override
	public boolean eTransponivel() {
		return true;
	}
}
