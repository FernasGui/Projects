package pt.iscte.poo.sokobanstarter.Elements;

import pt.iscte.poo.sokobanstarter.GameElement;
import pt.iscte.poo.sokobanstarter.GameEngine;
import pt.iscte.poo.utils.Point2D;

public class ParedeRachada extends GameElement {
	public ParedeRachada(Point2D Point2D, String imageName) {
		super(Point2D, "ParedeRachada", 2);
	}

	@Override
	public boolean eTransponivel() {
		return false;
	}
	 public void quebrar() {
		 GameEngine.getInstance().removeFromGame(this); // Remove a parede rachada do jogo
	    }
}
