package pt.iscte.poo.sokobanstarter;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Predicate;

import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.observer.Observed;
import pt.iscte.poo.observer.Observer;
import pt.iscte.poo.sokobanstarter.Elements.Alvo;
import pt.iscte.poo.sokobanstarter.Elements.Bateria;
import pt.iscte.poo.sokobanstarter.Elements.Buraco;
import pt.iscte.poo.sokobanstarter.Elements.Caixote;
import pt.iscte.poo.sokobanstarter.Elements.Chao;
import pt.iscte.poo.sokobanstarter.Elements.Empilhadora;
import pt.iscte.poo.sokobanstarter.Elements.Martelo;
import pt.iscte.poo.sokobanstarter.Elements.Palete;
import pt.iscte.poo.sokobanstarter.Elements.Parede;
import pt.iscte.poo.sokobanstarter.Elements.ParedeRachada;
import pt.iscte.poo.sokobanstarter.Elements.Teleporte;
import pt.iscte.poo.sokobanstarter.Elements.Vazio;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class GameEngine implements Observer {

	// Dimensoes da grelha de jogo
	public static final int GRID_HEIGHT = 10;
	public static final int GRID_WIDTH = 10;

	private static GameEngine INSTANCE; // Referencia para o unico objeto GameEngine (singleton)
	private ImageMatrixGUI gui; // Referencia para ImageMatrixGUI (janela de interface com o utilizador)
	private Empilhadora bobcat; // Referencia para a empilhadora
	private int numeroNivel = 0;
	private List<GameElement> elementos; // Lista de elementos
	private int numeroMovimentos; // nº movimentos
	private int nivelBateria; // nivel bateria
	private String nomeJog; // nome do jogador

	// Construtor - neste exemplo apenas inicializa uma lista de ImageTiles
	private GameEngine() {
		elementos = new ArrayList<>();
	}

	public List<GameElement> getElements() {
		return elementos;
	}

	// Implementacao do singleton para o GameEngine
	public static GameEngine getInstance() {
		if (INSTANCE == null)
			return INSTANCE = new GameEngine();
		return INSTANCE;
	}

	// Inicio
	public void start() {
		// Setup inicial da janela que faz a interface com o utilizador
		gui = ImageMatrixGUI.getInstance(); // 1. obter instancia ativa de ImageMatrixGUI
		gui.setSize(GRID_HEIGHT, GRID_WIDTH); // 2. configurar as dimensoes
		gui.registerObserver(this); // 3. registar o objeto ativo GameEngine como observador da GUI
		gui.go(); // 4. lancar a GUI
		nomeJog = gui.askUser("Qual é o seu nome?"); //pede o nome do jogador

		leituraDoFicheiro(); // // Criar o cenario de jogo ao ler o ficheiro
		sendImagesToGUI(); // enviar as imagens para a GUI
		gui.setStatusMessage("Sokoban " + " Bateria:" + nivelBateria);// Escrever uma mensagem na StatusBar
	}

	// O metodo update() é invocado automaticamente sempre que o utilizador carrega numa tecla
	// no argumento do metodo e' passada uma referencia para o objeto observado (neste caso a GUI)
	@Override
	public void update(Observed source) {
		int key = gui.keyPressed(); // Obtém o código da tecla pressionada

		if (Direction.isDirection(key)) {
			bobcat.move(Direction.directionFor(key)); // Move a empilhadora
			bobcat.diminuirEnergia(); // Decrementa a energia a cada movimento
			numeroMovimentos++;
			verificarInteracao(); // Verifica interações com objetos interactives
			verificarPerigo();
			verificarBateria(); // Verifica o nível da bateria
			verificarInteracaoMartelo(); // Verifica se a empilhadora pegou o martelo
			tentarQuebrarParede(bobcat.getPosition()); // Tenta quebrar a parede, se possível
			verificarTeleporte();

			// Atualiza a barra de status com a energia atual e se tem ou nao martelo
			gui.setStatusMessage(
					"Sokoban " + " Bateria: " + bobcat.getNivelBateria() + " Martelo= " + bobcat.temMartelo());
		} else if (key == KeyEvent.VK_R) {
			reiniciarNivel(); // Chama o método para reiniciar o jogo
		}
		gui.update(); // Atualiza a interface gráfica

		// Verifica se todos os alvos estão cobertos após o movimento
		if (verificarAlvosCobertos()) {
			exibirPontuacao(); // exibe a pontuação
			salvarPontuacao(); // Salva a pontuação em um arquivo
			avancarParaProximoNivel(); // Muda para o próximo nível se todos os alvos estiverem cobertos
		}
	}

	// FUNÇOES AUXILIARES
	private void sendImagesToGUI() {
		gui.clearImages(); // Limpa as imagens antigas da GUI
		for (ImageTile element : elementos) {
			gui.addImage(element); // Adiciona cada elemento à GUI
		}
		gui.update(); // Atualiza a GUI para mostrar os novos elementos
	}

	private void limparEstadoAtual() {
		gui.clearImages(); // Limpa a GUI antes de limpar a lista de elementos
		elementos.clear(); // Limpa a lista de elementos para o novo nível
	}

	public List<GameElement> getElementInPosition(Point2D p) {
		List<GameElement> list = new ArrayList<>();
		// Itera sobre todos os elementos do jogo
		for (GameElement element : this.elementos) {
			// Compara as posições diretamente
			if (element.getPosition().equals(p)) {
				list.add(element);
			}
		}
		return list;
	}

	// LEITURA DO FICHEIRO
	private void leituraDoFicheiro() {
		numeroMovimentos = 0;
		File f = new File("./levels/level" + numeroNivel + ".txt");

		// Declaração da lista de posições dos teleportes
		List<Point2D> posicoesTeleportes = new ArrayList<>();

		try (Scanner s = new Scanner(f)) {
			int y = 0;
			while (s.hasNextLine()) {
				String line = s.nextLine();

				for (int x = 0; x < line.length(); x++) { // Itera sobre os caracteres da linha

					Point2D position = new Point2D(x, y);
					switch (line.charAt(x)) {
					case '#':
						elementos.add(new Parede(position, "Parede"));
						break;
					case ' ':
						elementos.add(new Chao((position), "Chao"));
						break;
					case '=':
						elementos.add(new Vazio((position), "Vazio"));
						break;
					case 'C':
						elementos.add(new Chao((position), "Chao"));
						elementos.add(new Caixote((position), "Caixote"));
						break;
					case 'X':
						elementos.add(new Alvo((position), "Alvo"));
						break;
					case 'E':
						elementos.add(new Chao((position), "Chao"));
						bobcat = new Empilhadora((position), "Empilhadora_D"); // trocar img da empilhadora
						elementos.add(bobcat);
						break;
					case 'B':
						elementos.add(new Chao((position), "Chao"));
						elementos.add(new Bateria((position), "Bateria"));
						break;
					case 'T':
						elementos.add(new Teleporte((position), "Teleporte"));
						// Armazena a posição do teleporte
						posicoesTeleportes.add(position);
						break;
					case 'O':
						elementos.add(new Buraco((position), "Buraco"));
						break;
					case 'P':
						elementos.add(new Chao((position), "Chao"));
						elementos.add(new Palete((position), "Palete"));
						break;
					case 'M':
						elementos.add(new Chao((position), "Chao"));
						elementos.add(new Martelo((position), "Martelo"));
						break;
					case '%':
						elementos.add(new Chao((position), "Chao"));
						elementos.add(new ParedeRachada((position), "ParedeRachada"));
						break;
					}
				}
				y++;

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// Cria os objetos Teleporte com destinos mapeados
		for (int i = 0; i < posicoesTeleportes.size(); i += 2) {
			Point2D posicaoTeleporte1 = posicoesTeleportes.get(i);
			Point2D posicaoTeleporte2 = posicoesTeleportes.get(i + 1);
			elementos.add(new Teleporte(posicaoTeleporte1, "Teleporte", posicaoTeleporte2));
			elementos.add(new Teleporte(posicaoTeleporte2, "Teleporte", posicaoTeleporte1));
		}
		gui.update();
		sendImagesToGUI();
	}

	
	
	
	// EMPILHADORA
	private void processarElementosInterativos(Point2D posicao, Predicate<GameElement> condicao, Consumer<GameElement> acao) {
	    List<GameElement> elementosNaPosicao = GameEngine.getInstance().getElementInPosition(posicao);
	    for (GameElement elemento : elementosNaPosicao) {
	        if (elemento instanceof isInteractive && condicao.test(elemento)) {
	            acao.accept(elemento);
	        }
	    }
	}
	// método para verificar se a empilhadora está sobre um objeto interactivo
	private void verificarInteracao() {
		processarElementosInterativos(
			    bobcat.getPosition(),
			    objetoInterativo -> ((isInteractive)objetoInterativo).canBePickedUp(),
			    objetoInterativo -> ((isInteractive)objetoInterativo).onInteraction(bobcat)
			);
		//substitui isto pelo predicado
//		Point2D posicaoAtual = bobcat.getPosition();
//		List<GameElement> elementosNaPosicao = getElementInPosition(posicaoAtual);
//
//		for (GameElement elemento : elementosNaPosicao) {
//			if (elemento instanceof isInteractive) {
//				isInteractive objetoInterativo = (isInteractive) elemento;
//				if (objetoInterativo.canBePickedUp()) {
//					objetoInterativo.onInteraction(bobcat);
//				}
//			}
//		}
	}

	// BURACO
	private void processarElementosBuraco(Point2D posicao, Predicate<GameElement> condicao, Consumer<Buraco> acao) {
	    List<GameElement> elementosNaPosicao = GameEngine.getInstance().getElementInPosition(posicao);
	    for (GameElement elemento : elementosNaPosicao) {
	        if (elemento instanceof Buraco && condicao.test(elemento)) {
	            acao.accept((Buraco)elemento);
	        }
	    }
	}
	// Método para verificar o que acontece no buraco (perigo)
	private void verificarPerigo() {
		processarElementosBuraco(
			    bobcat.getPosition(),
			    elemento -> true, // Sempre verdadeiro, pois queremos processar todos os buracos
			    buraco -> {
			        if (!buraco.isCoberto()) {
			            reiniciarNivel();
			        }
			    }
			);
		//substitui isto pelo predicado
//	    Point2D posicaoAtual = bobcat.getPosition();
//	    List<GameElement> elementosNaPosicao = getElementInPosition(posicaoAtual);
//
//	    for (GameElement elemento : elementosNaPosicao) {
//	        if (elemento instanceof Buraco) {
//	            Buraco buraco = (Buraco) elemento;
//	            // Verifica se o buraco está coberto por uma palete
//	            if (!buraco.isCoberto()) {
//	            	reiniciarNivel(); // Só termina o jogo se o buraco não estiver coberto
//	                break;
//	            }
//	        }
//	    }
	}

	// ALVO
		// método para verificar se os alvos estao cobertos
		public boolean verificarAlvosCobertos() {
			// Itera por todos os elementos para encontrar os alvos
			for (GameElement elemento : elementos) {
				if (elemento instanceof Alvo) {
					boolean caixoteEmCima = false;

					// Verifica se há um caixote na mesma posição do alvo
					for (GameElement outroElemento : elementos) {
						if (outroElemento instanceof Caixote && outroElemento.getPosition().equals(elemento.getPosition())) {
							caixoteEmCima = true;
							break; // Encontrou um caixote sobre o alvo, interrompe a verificação interna
						}
					}

					// Se um alvo não está coberto por um caixote, retorna false
					if (!caixoteEmCima) {
						return false;
					}
				}
			}
			// Todos os alvos estão cobertos por caixotes, retorna true para avançar de nível
			return true;
		}
		
	// BATERIA
	// método para verificar o nível de bateria
	private void verificarBateria() {
		if (bobcat.getNivelBateria() <= 0) {
			gui.setMessage("Bateria esgotada! Reiniciando o nível.");
			reiniciarNivel();
		}
	}

	// MARTELO E PAREDE RACHADA
	// método para verificar a intereçao do martelo
	private void verificarInteracaoMartelo() {
		Point2D posicaoAtualEmpilhadora = bobcat.getPosition();
		List<GameElement> elementosNaPosicao = getElementInPosition(posicaoAtualEmpilhadora);

		for (GameElement elemento : elementosNaPosicao) {
			if (elemento instanceof Martelo && ((Martelo) elemento).canBePickedUp()) {
				((Martelo) elemento).onInteraction(bobcat);
			}
		}
	}

	// método para quebrar a parede
	private void tentarQuebrarParede(Point2D posicao) {
		if (!bobcat.temMartelo()) {
			return;
		}
		List<GameElement> elementosNaPosicao = getElementInPosition(posicao);
		for (GameElement elemento : elementosNaPosicao) {
			if (elemento instanceof ParedeRachada) {
				bobcat.usarMartelo((ParedeRachada) elemento);
			}
		}
	}

	// TELEPORTE
	// método para verificar o teleporte
	private void verificarTeleporte() {
		Point2D posicaoAtual = bobcat.getPosition();
		List<GameElement> elementosNaPosicao = getElementInPosition(posicaoAtual);

		for (GameElement elemento : elementosNaPosicao) {
			if (elemento instanceof Teleporte) {
				Teleporte teleporte = (Teleporte) elemento;
				teletransportar(bobcat, teleporte);
				break;
			}
		}
	}

	// método para teleportar
	private void teletransportar(Moveable moveable, Teleporte teleporte) {
		Point2D destino = teleporte.getDestino();
		if (destino != null) {
			moveable.setPosition(destino);
			updateElementPosition(moveable, destino);
		}
	}

	// método para atualizar
	public void updateElementPosition(GameElement element, Point2D newPosition) {
		// Atualiza a posição do elemento
		element.setPosition(newPosition);
	}

	// NIVEL
	// método para reniciar o nível
	private void reiniciarNivel() {
		gui.setMessage("Perdeu!  O jogo será reiniciado.");
		limparEstadoAtual();
		numeroMovimentos = 0; // renicia o nº de movimentos
		leituraDoFicheiro(); // Recarrega o nível inicial
		gui.update();
	}

	// método para reniciar o jogo
	private void reiniciarJogo() {
		limparEstadoAtual();
		numeroMovimentos = 0; // renicia o nº de movimentos
		numeroNivel = 0;
		leituraDoFicheiro(); // Recarrega o nível inicial
		gui.update();
	}

	// método para perder e reniciar o jogo
	private void perderJogo() {
		gui.setMessage("GAMEOVER!  O jogo será reiniciado.");
		reiniciarJogo();
	}

	public void avancarParaProximoNivel() {
		if (numeroNivel < 6)
			numeroNivel++;// Incrementa o número do nível
		else
			perderJogo();// talvez mudar isto para outra funçao!!!!!!

		limparEstadoAtual(); // Limpa o estado atual do jogo antes de carregar o novo nível
		leituraDoFicheiro();// Carrega o próximo nível
		gui.update();// Atualiza a interface gráfica para refletir o novo nível
	}

	// PONTUAÇÃO
	// fazer um ficheiro de texto para guardar a pontuação
	public void exibirPontuacao() {
		String mensagem = "Jogador:" + nomeJog + "\nPassou o nível: " + numeroNivel + "\nNúmero de movimentos: "
				+ numeroMovimentos;
		gui.setMessage(mensagem);
	}

	private void salvarPontuacao() {
		try (FileWriter fw = new FileWriter("pontuacao.txt", true); PrintWriter out = new PrintWriter(fw)) {

			out.println("Jogador: " + nomeJog);
			out.println("Nível: " + numeroNivel);
			out.println("Movimentos: " + numeroMovimentos);
			out.println(); // Adiciona uma linha em branco para separar as entradas

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// REMOVER
	// método para remover um elemento do jogo
	public void removeFromGame(GameElement element) {
		elementos.remove(element); // Remove o elemento da lista de elementos do jogo
		gui.removeImage(element); // Remove a imagem do elemento da GUI
		gui.update(); // Atualiza a GUI
	}

	// apenas remove do gameelement mas nao visualmente
	public void removeElement(GameElement element) {
		elementos.remove(element);
		// Não chama gui.removeImage(element), mantendo a imagem na interface gráfica
		gui.update(); // Atualiza a GUI
	}
}
