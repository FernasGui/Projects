package pt.iscte.poo.sokobanstarter;

import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Point2D;

public abstract class GameElement implements ImageTile {

	private Point2D Point2D;
	private String imageName;
	private int layer;


	public GameElement(Point2D Point2D, String imageName, int layer) {
		this.imageName = imageName;
		this.Point2D = Point2D;
		this.layer = layer;
	}

	public String getName() {
		return imageName;
	}

	public Point2D getPosition() {
		return Point2D;
	}

	public int getLayer() {
		return layer;
	}

	public void setPosition(Point2D point2d) {
		Point2D = point2d;
	}

	public void setImage(String imageName) {
		this.imageName = imageName;
	}

	public abstract boolean eTransponivel();
}
