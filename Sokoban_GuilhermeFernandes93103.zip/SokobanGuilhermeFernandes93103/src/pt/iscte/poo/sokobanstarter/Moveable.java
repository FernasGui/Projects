package pt.iscte.poo.sokobanstarter;

import java.util.List;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public abstract class Moveable extends GameElement {
	public Moveable(Point2D Point2D, String imageName, int layer) {
		super(Point2D, imageName, layer);
	}

	public boolean canMove(Direction d) {
		// Calcula a nova posição com base na direção fornecida
		Point2D newPosition = getPosition().plus(d.asVector());

		// Obtém a lista de elementos na nova posição
		List<GameElement> elementsInNewPosition = GameEngine.getInstance().getElementInPosition(newPosition);
		for (GameElement element : elementsInNewPosition) {
			// Verifica se os elementos na nova posição são transponíveis
			if (!element.eTransponivel()) {
				return false; // Não pode se mover se houver um elemento intransponível
			}
		}

		return true; // Pode se mover se todos os elementos na posição forem transponíveis
	}

	public void move(Direction d) {
		// Calcula a nova posição com base na direção fornecida
		Point2D newPosition = getPosition().plus(d.asVector());
		// Verifica se pode mover para a nova posição
		if (canMove(d)) {
			setPosition(newPosition);
		}
	}
}
