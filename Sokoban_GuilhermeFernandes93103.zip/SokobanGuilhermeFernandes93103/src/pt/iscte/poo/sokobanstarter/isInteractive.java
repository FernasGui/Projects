package pt.iscte.poo.sokobanstarter;

public interface isInteractive {

    // Método que verifica se o objeto pode ser apanhado ou interagido
    boolean canBePickedUp();

    // Método que define a ação ao interagir com o objeto
    void onInteraction(GameElement element);
}
